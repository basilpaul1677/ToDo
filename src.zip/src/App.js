import React, { useState } from 'react';
import './App.css';

import View from './components/Viewtodo'; 

function App() {
  const [todo, setTodo] = useState("");  
  const [todos, setTodos] = useState([]); 

  const handleInputChange = (event) => {
    setTodo(event.target.value);
  };

  const handleAddTodo = (event) => {
    event.preventDefault();  
    if (todo.trim()) {
      setTodos([...todos, todo]); 
      setTodo('');
    }
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>To-Do List</h1>

        {/* Form for adding tasks */}
        <form onSubmit={handleAddTodo}>
          <input 
            type="text" 
            placeholder="Add a new task..." 
            value={todo} 
            onChange={handleInputChange}
          />
          <button type="submit">Add Task</button>
        </form>

        <View todos={todos} />
      </header>
    </div>
  );
}

export default App;
