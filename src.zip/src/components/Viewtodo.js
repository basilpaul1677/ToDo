import React from 'react';

function View({ todos }) { 
    return (
        <div className="App-header">
            <h1>Your ToDo List Till now:</h1>
            <ul>
            {Array.isArray(todos) && todos.length > 0 ? (
                    todos.map((todo, index) => (
                        <li key={index}>{todo}</li>
                    ))
                ) : (
                    <p>No todos yet!!!</p> 
                )}
            </ul>
        </div>
    );
}

export default View;
