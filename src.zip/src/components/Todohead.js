import React from 'react';

function Heading({ todo, onInputChange, onAddTodo }) {
    
    return (
        <form onSubmit={onAddTodo}>
            <h1>Enter your ToDo List :</h1>
            <input
                type="text"
                id="todolist"
                value={todo}          
                onChange={onInputChange} 
                placeholder="Add a new task"
            />
            <button type="submit" id="btn">Add List</button>
        </form>
    );
}

export default Heading;
